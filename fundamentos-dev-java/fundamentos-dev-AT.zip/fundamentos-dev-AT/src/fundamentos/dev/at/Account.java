package fundamentos.dev.at;

import enums.AccountTypeEnum;

public abstract class Account {
    private AccountTypeEnum type;
    private String name;
    private int accountNumber;
    private double accountBalance;
    
    public Account() {}
    
    public Account(AccountTypeEnum type, String name, int accountNumber, double accountBalance) {
        this.type = type;
        this.name = name;
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
    }
    
    public AccountTypeEnum getType() {
        return type;
    }
    
    public void setType(AccountTypeEnum type) {
        this.type = type;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }
    
    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Tipo da conta: ").append(type).append("\n");
        sb.append("Name: ").append(name).append("\n");
        sb.append("Número da conta: ").append(accountNumber).append("\n");
        sb.append("Saldo: ").append(accountBalance).append("\n");
        return sb.toString();
    }
}
