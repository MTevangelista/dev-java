package fundamentos.dev.at;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Scanner;
import constants.Constants;
import enums.AccountTypeEnum;
import enums.MessageTypesEnum;
import static fundamentos.dev.at.Main.showMessage;


public class FileManager {
    private static String fileName;
    
    public static void setFileName(String name) {
        fileName = name;
    }
    
    public static Scanner openTheReading() {
        Scanner scanner = null;
        
        try {
            System.out.println(fileName);
            scanner = new Scanner(new File(fileName));
        } catch (FileNotFoundException ex) {
            showMessage(MessageTypesEnum.ERR, Constants.FILE_OPEN_ERROR);
        }
        return scanner;
    }
    
    public static void readFile(Scanner entrada, ArrayList<AccountPF> accountsPF, ArrayList<AccountPJ> accountsPJ) {
        String line;
        String[] fields;
        
        while (entrada.hasNext()) {
            line = entrada.nextLine();
            fields = line.split(";");
            if (fields[0] == AccountTypeEnum.PF.toString()) {
                AccountPF accountPF = new AccountPF(AccountTypeEnum.PF, fields[1], Integer.parseInt(fields[2]), Double.parseDouble(fields[3]), fields[4], Double.parseDouble(fields[5]));
                accountsPF.add(accountPF);
            } else {
                AccountPJ accountPJ = new AccountPJ(AccountTypeEnum.PJ, fields[1], Integer.parseInt(fields[2]), Double.parseDouble(fields[3]), fields[4]);
                accountsPJ.add(accountPJ);
            }
        }
    }
    
    public static Formatter openTheRecording() {
        Formatter exit = null;
        
        try {
            exit = new Formatter(fileName);
        } catch (FileNotFoundException ex) {
            showMessage(MessageTypesEnum.ERR, Constants.FILE_NOT_FOUND);
        }
        return exit;
    }
    
    public static void saveAccountPF(Formatter exit, ArrayList<AccountPF> accounts) {
        for (AccountPF account : accounts) {
            exit.format("%s;%s;%s;%s;%s;%s\n", account.getType(), account.getAccountNumber(), account.getName(), account.getAccountBalance(), account.getCPF(), account.getSpecialCheck());
        }
    }
    
    public static void saveAccountPJ(Formatter exit, ArrayList<AccountPJ> accounts) {
        for (AccountPJ account : accounts) {
            exit.format("%s;%s;%s;%s;%s;%s\n", account.getType(), account.getAccountNumber(), account.getName(), account.getAccountBalance(), account.getCNPJ());
        }
    }
    
    public static void CloseFile(Formatter exit) {
        
        if (exit != null) {
            exit.close();
        }
    }
    
    public static void CloseFile(Scanner scanner) {
        
        if (scanner != null) {
            scanner.close();
        }        
    }
}
