package fundamentos.dev.at;

import constants.Constants;
import enums.AccountTypeEnum;
import enums.MenuOptionsTypeEnum;
import enums.MessageTypesEnum;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.InputMismatchException;
import java.util.Scanner;
import validation.DataValidation;

public class Main {
    public static void main(String[] args) {
        final int END = 5;
        int option;
        ArrayList<AccountPF> accountsPF = new ArrayList<>();
        ArrayList<AccountPJ> accountsPJ = new ArrayList<>();
        Scanner scanner;
        
        FileManager.setFileName(Constants.FILE_NAME);
        scanner = FileManager.openTheReading();
        if (scanner != null) {
            FileManager.readFile(scanner, accountsPF, accountsPJ);
            FileManager.CloseFile(scanner);
        }
        else {
            showMessage(MessageTypesEnum.ERR, Constants.FILE_READ_ERROR);
        }
        
        option = menu(MenuOptionsTypeEnum.USER_OPTIONS);
        while (option != END) {
            start(option, accountsPF, accountsPJ);
            showMessage(MessageTypesEnum.OUT, Constants.EMPTY_MESSAGE);
            option = menu(MenuOptionsTypeEnum.USER_OPTIONS);
        }
    }
    
    private static int menu(MenuOptionsTypeEnum optionsType) {
        int option;
        String menuOptions = "";
        
        switch (optionsType) {
            case USER_OPTIONS:
                menuOptions = Constants.USER_OPTIONS_MENU;
                break;
            case ACCOUNT_TYPES_MENU:
                menuOptions = Constants.ACCOUNT_TYPES_OPTIONS_MENU;
                break;
            default:
                showMessage(MessageTypesEnum.ERR, Constants.INVALID_MESSAGE_TYPE);
                break;
        }
        option = readIntValue(menuOptions);
        return option;
    }
    
    private static void start(int option, ArrayList<AccountPF> accountsPF, ArrayList<AccountPJ> accountsPJ) {
        switch (option) {
            case 1:
                registerAccount(accountsPF, accountsPJ);
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                getAllAccounts(accountsPF, accountsPJ);
                break;
            default:
                showMessage(MessageTypesEnum.OUT, Constants.INVALID_OPERATION);
                break;
        }
    }
    
    private static int getAccountType() {
        int option = menu(MenuOptionsTypeEnum.ACCOUNT_TYPES_MENU);
        return option;
    }
    
    private static void registerAccount(ArrayList<AccountPF> accountsPF, ArrayList<AccountPJ> accountsPJ) {
        int accountType = getAccountType();
        
        switch (accountType) {
            case 1:
                registerAccountPF(accountsPF, accountsPJ);
                break;
            case 2: 
                registerAccountPJ(accountsPJ, accountsPF);
                break;
            default:
                showMessage(MessageTypesEnum.ERR, Constants.INVALID_OPERATION);
                break;
        }
    }
    
    private static void registerAccountPF(ArrayList<AccountPF> accounts, ArrayList<AccountPJ> accountsPJ) {
        AccountPF accountPF = new AccountPF();
        Formatter exit;
        
        accountPF.setAccountNumber(readIntValue(Constants.ENTER_YOUR_ACCOUNT_NUMBER));
        if (DataValidation.hasRepeatedAccount(accountPF.getAccountNumber(), accounts, accountsPJ)) {
            showMessage(MessageTypesEnum.ERR, Constants.ACCOUNT_ALREADY_EXISTS);
        } else {
            accountPF.setType(AccountTypeEnum.PF);
            accountPF.setName(readName(Constants.ENTER_YOUR_ACCOUNT_HOLDER_NAME));
            accountPF.setCPF(String.valueOf(readIntValue(Constants.ENTER_YOUR_CPF)));
            accountPF.setAccountBalance(readBalance(Constants.ENTER_YOUR_ACCOUNT_BALANCE));
            accounts.add(accountPF);
            showMessage(MessageTypesEnum.OUT, Constants.ACCOUNT_REGISTER_SUCCESSFULLY);
        
            exit = FileManager.openTheRecording();
            FileManager.saveAccountPF(exit, accounts);
            FileManager.CloseFile(exit);
        }
    }
    
    private static void registerAccountPJ(ArrayList<AccountPJ> accounts, ArrayList<AccountPF> accountsPF) {
        AccountPJ accountPJ = new AccountPJ();

        accountPJ.setAccountNumber(readIntValue(Constants.ENTER_YOUR_ACCOUNT_NUMBER));
        if (DataValidation.hasRepeatedAccount(accountPJ.getAccountNumber(), accountsPF, accounts)) {
            showMessage(MessageTypesEnum.ERR, Constants.ACCOUNT_ALREADY_EXISTS);
        } else {
            accountPJ.setType(AccountTypeEnum.PJ);
            accountPJ.setName(readName(Constants.ENTER_YOUR_COMPANY_NAME));
            accountPJ.setCNPJ(String.valueOf(readIntValue(Constants.ENTER_YOUR_CNPJ)));
            accountPJ.setAccountBalance(readBalance(Constants.ENTER_YOUR_ACCOUNT_BALANCE));
            accounts.add(accountPJ);
        }
    }
    
    private static void getAllAccounts(ArrayList<AccountPF> accountsPF, ArrayList<AccountPJ> accountsPJ) {
        showMessage(MessageTypesEnum.OUT, Constants.ACCOUNT_PF);
        for (AccountPF accountPF : accountsPF) {
            showMessage(MessageTypesEnum.OUT, accountPF.toString());
        }
        
        showMessage(MessageTypesEnum.OUT, Constants.ACCOUNT_PJ);
        for (AccountPJ accountPJ : accountsPJ) {
            showMessage(MessageTypesEnum.OUT, accountPJ.toString());
        }
    }
    
    private static String readName(String msg) {
        String value;
        Scanner scanner = new Scanner(System.in);
        
        showMessage(MessageTypesEnum.OUT, msg);
        value = scanner.nextLine();
        while(!DataValidation.isValidName(value)) {
            showMessage(MessageTypesEnum.ERR, Constants.INVALID_NAME);
            showMessage(MessageTypesEnum.OUT, msg);
            value = scanner.nextLine();
        }
        return value;
    }

    private static int readIntValue(String menuOptions) {
        int value = 0;
        boolean isValidInput = false;
        Scanner scanner = new Scanner(System.in);
        
        do {            
            try {
                showMessage(MessageTypesEnum.OUT, menuOptions);
                value = scanner.nextInt();
                isValidInput = true;
            } catch (InputMismatchException e) {
                showMessage(MessageTypesEnum.ERR, Constants.INVALID_DATA);
                scanner.next();
            }
        } while (!isValidInput);
        return value;
    }
    
    private static double readBalance(String msg) {
        double value = 0;
        boolean isValidInput = false;
        Scanner scanner = new Scanner(System.in);
        
        do {
            try {
                showMessage(MessageTypesEnum.OUT, msg);
                value = scanner.nextDouble();
                while (!DataValidation.hasValidBalance(value)) {
                    showMessage(MessageTypesEnum.ERR, Constants.INVALID_BALANCE);
                    showMessage(MessageTypesEnum.OUT, msg);
                    value = scanner.nextDouble();
                }
                isValidInput = true;
            } catch (InputMismatchException e) {
                showMessage(MessageTypesEnum.ERR, Constants.INVALID_DATA);
                scanner.next();
            }
        } while (!isValidInput);
        return value;
    }
    
    public static void showMessage(MessageTypesEnum type, String msg) {
        switch (type) {
            case OUT: System.out.println(msg); break;
            case ERR: System.err.println(msg); break;
            default: System.err.println(Constants.INVALID_MESSAGE_TYPE); break;
        }
    }
}
