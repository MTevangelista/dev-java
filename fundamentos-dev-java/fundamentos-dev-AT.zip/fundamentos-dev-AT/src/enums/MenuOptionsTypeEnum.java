package enums;

public enum MenuOptionsTypeEnum {
    USER_OPTIONS,
    ACCOUNT_TYPES_MENU
}
