package enums;

public enum AccountTypeEnum {
    PF,
    PJ
}
