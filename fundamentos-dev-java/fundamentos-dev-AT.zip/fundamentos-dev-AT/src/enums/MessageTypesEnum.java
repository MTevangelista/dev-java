package enums;

public enum MessageTypesEnum {
    OUT,
    ERR
}
