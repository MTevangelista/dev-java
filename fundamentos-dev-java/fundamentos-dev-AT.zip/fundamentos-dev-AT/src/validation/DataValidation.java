package validation;

import fundamentos.dev.at.AccountPF;
import fundamentos.dev.at.AccountPJ;
import java.util.ArrayList;

public class DataValidation {
    public static boolean isValidName(String name) {
        String[] splittedName = name.split(" ");
        return splittedName.length >= 2;
    }
    
    public static boolean hasRepeatedAccount(int accountNumber, ArrayList<AccountPF> accountsPF, ArrayList<AccountPJ> accountsPJ) {
        boolean hasAccount = false;
        
        for (AccountPF account : accountsPF) {
            if (account.getAccountNumber() == accountNumber) {
                hasAccount = true;
                break;
            }
        }
        
        if (!hasAccount) {
            for (AccountPJ account : accountsPJ) {
                if (account.getAccountNumber() == accountNumber) {
                    hasAccount = true;
                    break;
                }
            }
        }

        return hasAccount;
    }

    public static boolean hasValidBalance(double balance) {
        return balance >= 0;
    }
}
