package br.edu.infnet.springmvc.constants;

public final class JSPPagesConstants {
    public static final String LANDING = "landing";
    public static final String SIGNUP = "signup";
    public static final String PROFILE = "profile";
}
