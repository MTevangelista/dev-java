package br.edu.infnet.springmvc.constants;

public final class RoutersConstants {
    public static final String INDEX_ROUTER = "";
    public static final String SIGNUP_ROUTER = "/signup";
    public static final String PROFILE_ROUTER = "/profile";
}
