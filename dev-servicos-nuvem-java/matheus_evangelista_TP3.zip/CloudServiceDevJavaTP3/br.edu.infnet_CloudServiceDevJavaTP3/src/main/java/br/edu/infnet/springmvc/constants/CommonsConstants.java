package br.edu.infnet.springmvc.constants;

public final class CommonsConstants {
    public static final String USER = "user";
    public static final String ERROR_MESSAGE_JSP_VAR = "errorMessage";
}

