package br.edu.infnet.springmvc.constants;

public final class FormActionsConstants {
    public static final String HANDLE_SIGNUP = "handleSignUp";
    public static final String HANDLE_UPDATE_USER = "handleUpdateUser";
}
