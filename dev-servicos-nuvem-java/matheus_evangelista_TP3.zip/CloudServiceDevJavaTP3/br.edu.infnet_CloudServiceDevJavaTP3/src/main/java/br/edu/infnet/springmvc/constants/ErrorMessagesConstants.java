package br.edu.infnet.springmvc.constants;

public final class ErrorMessagesConstants {
    public static final String INVALID_CREDENTIALS = "Credenciais inválidas";
    public static final String EMAIL_ALREADY_EXISTS = "E-mail já existe";
}
