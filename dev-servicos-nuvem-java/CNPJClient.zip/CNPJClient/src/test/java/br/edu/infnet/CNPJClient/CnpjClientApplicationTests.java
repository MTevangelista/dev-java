package br.edu.infnet.CNPJClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CnpjClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
