package br.edu.infnet.APIClientTP1DR4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiClientTp1Dr4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
