package br.edu.infnet.SpringMVCPU;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcpuApplicationTests {

	@Test
	void contextLoads() {
	}

}
