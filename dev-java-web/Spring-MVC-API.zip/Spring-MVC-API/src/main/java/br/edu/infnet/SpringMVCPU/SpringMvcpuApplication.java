package br.edu.infnet.SpringMVCPU;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcpuApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringMvcpuApplication.class, args);
    }
}
